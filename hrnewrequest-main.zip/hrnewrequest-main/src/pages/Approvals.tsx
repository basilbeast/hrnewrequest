import Nav from '../components/Nav'
function Approvals() {
    return (
      <>
        <Nav/>
        
      </>
    )
  }
  
  export default Approvals